package com.techprimers.designpatterns.abstractfactory;

public class GooglePhone implements Phone {

    public void display() {
        System.out.println("Google Pixel 2");
    }
}
