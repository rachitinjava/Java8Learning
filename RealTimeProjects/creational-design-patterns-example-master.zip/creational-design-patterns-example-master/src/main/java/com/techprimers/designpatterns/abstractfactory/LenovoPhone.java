package com.techprimers.designpatterns.abstractfactory;

public class LenovoPhone implements Phone {
    public void display() {
        System.out.println("Lenovo K5 Note");
    }
}
