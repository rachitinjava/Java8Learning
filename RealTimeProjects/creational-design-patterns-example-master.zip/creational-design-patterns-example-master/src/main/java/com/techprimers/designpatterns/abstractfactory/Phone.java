package com.techprimers.designpatterns.abstractfactory;

public interface Phone {
    void display();
}
